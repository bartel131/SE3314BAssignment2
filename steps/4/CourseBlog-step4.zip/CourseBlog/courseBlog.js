/**
 * Created by Abdelkader on 2015-01-31.
 */
CourseBlog = Ember.Application.create();